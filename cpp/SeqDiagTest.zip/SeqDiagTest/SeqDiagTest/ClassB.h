#pragma once

class ClassB
{
public:
	ClassB(void);
	~ClassB(void);
	int b_method(int param);
};
