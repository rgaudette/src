#include "ClassB.h"

ClassB::ClassB(void)
{
}

ClassB::~ClassB(void)
{
}

int ClassB::b_method(int param)
{
	return 0;
}
