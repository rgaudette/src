// SeqDiagTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ClassA.h"

int _tmain(int argc, _TCHAR* argv[])
{
	ClassA ca;
	ca.a_method(2);

	return 0;
}

