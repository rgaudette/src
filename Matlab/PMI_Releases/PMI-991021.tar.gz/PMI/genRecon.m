%GenRecon       Generate the selected Reconstruction.
%
%   pmi = genRecon(pmi)
%
%   pmi          The Photon Migration Imaging data structure with result
%                included.
%
%   GenRecon generates the reconstruction specified in the PMI data structure
%   and if requested prints out performance measures of the reconstruction.
%
%   Calls: art, sirt, fatmn, fattsvd, fatmtsvd, tcgls
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 19:29:38 $
%
%  $Revision: 3.0 $
%
%  $Log: genRecon.m,v $
%  Revision 3.0  1999/06/17 19:29:38  rjg
%  Initial Revision for PMI 3.0
%
%  Revision 2.1  1999/02/05 20:43:34  rjg
%  Added help brief comments.
%
%  Revision 2.0  1999/02/05 20:40:09  rjg
%  *** empty log message ***
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = genRecon(pmi)

%%
%%  Calculate an esimate of the weighted scattered field
%%
WScatEst = pmi.PhiTotalNw - pmi.Noise.w .* pmi.Inv.PhiInc;

%%
%%  Reconstruct image of volume
%%
nVoxels = size(pmi.Inv.A, 2);
nLambda = size(WScatEst, 2);


%%
%%  Compute x estimate using requested algorithm
%%
pmi.Recon.xEst = zeros(nVoxels, nLambda);
switch pmi.Recon.ReconAlg

case 'Back Projection'
    for j = 1:nLambda
        %%
        %%  Rescale the backprojection matrix such test the norm of the rows
        %%  of the transpose of A are equal to 1.
        %%
        BPO = zeros(nVoxels, size(pmi.Inv.A, 1));
        for i = 1:nVoxels
            temp = pmi.Inv.A(:,i,j)';
            BPO(i,:) = temp ./ norm(temp);
        end
        pmi.Recon.xEst(:,j) = BPO * WScatEst(:,j);
    end

case 'ART'
    for j = 1:nLambda
        pmi.Recon.xEst(:,j) = art(pmi.Inv.Aw(:,:,j), WScatEst(:,j), ...
            zeros(nVoxels, 1), pmi.Recon.ARTnIter);
    end

case 'SIRT'
    for j = 1:nLambda
        pmi.Recon.xEst(:,j) = sirt(pmi.Inv.Aw(:,:,j), WScatEst(:,j), ...
            zeros(nVoxels, 1), pmi.Recon.SIRTnIter);
    end
    
case 'Min. Norm'
    for j = 1:nLambda
        pmi.Recon.xEst(:,j) = fatmn(pmi.Inv.Aw(:,:,j), WScatEst(:,j));
    end
    
case 'TSVD'
    for j = 1:nLambda
        if pmi.Recon.flgNeedEconSVD
            if pmi.Debug
                disp('Computing economy SVD');
            end
            if j == 1
                pmi.Recon.Secon = []
                pmi.Recon.Vecon = [];
                pmi.Recon.Uecon = [];
            end
            
            [pmi.Recon.xEst(:,j) pmi.Recon.Uecon(:,:,j) ...
                    pmi.Recon.Secon(:,:,j) pmi.Recon.Vecon(:,:,j)] = ...
                fattsvd(pmi.Inv.Aw(:,:,j), WScatEst(:,j), pmi.Recon.TSVDnSV);
            if j == nLambda
                pmi.Recon.flgNeedEconSVD = 0;
            end
        else
            if pmi.Debug
                disp('Already have economy SVD');
            end
            pmi.Recon.xEst(:,j) = fattsvd(pmi.Inv.Aw(:,:,j), WScatEst(:,j), ...
                pmi.Recon.TSVDnSV, pmi.Recon.Uecon(:,:,j), ...
                pmi.Recon.Secon(:,:,j), pmi.Recon.Vecon(:,:,j));
        end
    end
    
case 'MTSVD'
    LaplOp = lapl3d(length(pmi.Inv.CompVol.X),length(pmi.Inv.CompVol.Y),...
        length(pmi.Inv.CompVol.Z));
    for j = 1:nLambda
        if pmi.Recon.flgNeedFullSVD
            %%
            %%  If the system has changed we must recompute the full SVD as
            %%  well as the MTSVD solution
            %%
            if pmi.Debug
                fprintf('Computing full MTSVD\n')
            end
            pmi.Recon.xTSVD = zeros(nVoxels, nLambda);
            pmi.Recon.xNS = zeros(nVoxels, nLambda);
            pmi.Recon.S = [];
            pmi.Recon.V = [];
            pmi.Recon.U = [];
            [pmi.Recon.xEst(:,j) pmi.Recon.xTSVD(:,j) pmi.Recon.xNS(:,j) ...
                    pmi.U(:,:,j) pmi.S(:,:,j) pmi.V(:,:,j)] = ...
                fatmtsvd(pmi.Inv.Aw(:,:,j), WScatEst(:,j), ...
                pmi.Recon.MTSVDnSV, LaplOp, pmi.Recon.MTSVDLambda);
            prev_nSV = pmi.Recon.MTSVDnSV;
            if j == nLambda
                pmi.Recon.flgNeedFullSVD = 0;
            end

        elseif pmi.Recon.MTSVDnSV == prev_nSV
            %%
            %%  If all test has been modified is lambda we can quickly compute
            %%  the result.
            %%
            if pmi.Debug
                fprintf('Only changed lambda\n')
            end
            pmi.Recon.xEst(:,j) = pmi.Recon.xTSVD(:,j) - ...
                pmi.Recon.MTSVDLambda * pmi.Recon.xNS(:,j);
            
    
        else    
            %%
            %%  If the system is still the same then recompute using the
            %%  existing SVD computation
            %% 
            if pmi.Debug
                fprintf('Recomputing optimum NULL space contribution\n')
            end
            [pmi.Recon.xEst(:,j) pmi.Recon.xTSVD(:,j) pmi.Recon.xNS(:,j)] = ...
                fatmtsvd(pmi.Inv.Aw(:,:,j), WScatEst(:,j), ...
                pmi.Recon.MTSVDnSV, LaplOp, pmi.MTSVDLambda, ...
                pmi.Recon.U(:,:,j), pmi.Recon.S(:,:,j), pmi.Recon.V(:,:,j));
            prev_nSV = pmi.Recon.MTSVDnSV;
        end
    end

case 'TCG'
    %%
    %%  Truncated normal equation solution
    %%
    for j = 1:nLambda
        pmi.Recon.xEst(:,j) = tcgls(pmi.Inv.Aw(:,:,j), WScatEst(:,j), ...
            pmi.Recon.TCGnIter);
    end
    
otherwise
    error(['Unknown Reconstruction technique: ' pmi.Recon.ReconAlg]);
end

%%
%%  Print out performance measures of the Reconstruction
%%
if pmi.Debug > 0
    pmi.Recon.xError = [];
    pmi.Recon.xResid = [];
    nLambda = size(pmi.Fwd.Mu_a, 2);
    for j = 1:nLambda
        delMu_a = calcDelMuA(pmi.Object, pmi.Inv.CompVol, pmi.Inv.Mu_a, j);
        delMu_a = delMu_a(:);
        pmi.Recon.xError(:,j) = pmi.Recon.xEst(:,j) - delMu_a;
        fprintf('Lambda #%d\n', j);
        fprintf('  Normalized 2-norm of the error: %f\n', ...
                norm(pmi.Recon.xError(:,j))/norm(delMu_a));
        fprintf('  Mean abs value of the error: %f\n', ...
            mean(abs(pmi.Recon.xError(:,j))));

        fprintf('  Maximum difference %f\n', max(pmi.Recon.xError(:,j)));
        fprintf('  Minimum difference %f\n', min(pmi.Recon.xError(:,j)));

        pmi.Recon.xResid(:,j) = pmi.Inv.Aw(:,:,j) * pmi.Recon.xEst(:,j) - ...
            WScatEst(:,j);
        fprintf('  2-norm of residual: %f\n', norm(pmi.Recon.xResid(:,j)));
    end
end
