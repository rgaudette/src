%GenNoise       Generate the noise vector and noise scattered field.
%
%   pmi = gennoise(pmi);
%
%   pmi         The Photon Migration Imaging data structure to updated.
%
%
%   GenNoise generates instances the selected noise models in the PMI data
%   structure.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 19:29:38 $
%
%  $Revision: 3.0 $
%
%  $Log: genNoise.m,v $
%  Revision 3.0  1999/06/17 19:29:38  rjg
%  Initial Revision for PMI 3.0
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = genNoise(pmi);

%%
%%  Copy in the non-noise scattered field into the noise modified
%%  scattered field.
%%
pmi.PhiTotalN = pmi.PhiTotal;

TotalVar = zeros(size(pmi.PhiTotal));
[nMeas nLambda] = size(pmi.PhiTotal);

%%
%%  Add source side noise relative to the total field if selected
%%
if pmi.Noise.SrcSNRflag
    SrcNoiseSTD  = abs(pmi.PhiTotal) * (10 ^ (-1 * pmi.Noise.SrcSNR / 20));
    TotalVar = TotalVar + SrcNoiseSTD .^ 2;
    SrcNoise = randn(nMeas, nLambda) .* SrcNoiseSTD;
    pmi.PhiTotalN = pmi.PhiTotalN + SrcNoise;
    if pmi.Debug
        pmi.Noise.SrcNoiseSTD = SrcNoiseSTD;
        pmi.Noise.SrcNoise = SrcNoise;
        fprintf('Max source noise std %e\n', max(pmi.Noise.SrcNoiseSTD));
        fprintf('Min source noise std %e\n\n', min(pmi.Noise.SrcNoiseSTD));
    end
end

%%
%%  Add detector side noise relative to the total field if selected.
%%
if pmi.Noise.DetSNRflag
    DetNoiseSTD = max(abs(pmi.PhiTotal)) * (10 ^ (-1 * pmi.Noise.DetSNR / 20));
    
    TotalVar = TotalVar + repmat(DetNoiseSTD .^ 2, nMeas, 1);
    DetNoise = randn(nMeas, nLambda) * diag(DetNoiseSTD);
    pmi.PhiTotalN = pmi.PhiTotalN + DetNoise;
    if pmi.Debug
        pmi.Noise.DetNoiseSTD = DetNoiseSTD;
        pmi.Noise.DetNoise = DetNoise;
        fprintf('Detector noise std %e\n\n', pmi.Noise.DetNoiseSTD);
    end
end


%%
%%  Add scattered ratio noise relative to the peak scattered field if
%%  selected.
%%
if pmi.Noise.ScatSNRflag
    ScatNoiseSTD = max(abs(pmi.Fwd.PhiScat)) * ...
        (10 ^ (-1 * pmi.Noise.ScatSNR / 20));
    TotalVar = TotalVar + repmat(ScatNoiseSTD .^ 2, nMeas, 1);
    ScatNoise = randn(nMeas, nLambda) .* repmat(ScatNoiseSTD, nMeas, 1);
    pmi.PhiTotalN = pmi.PhiTotalN + ScatNoise;
    if pmi.Debug
        pmi.Noise.ScatNoiseSTD = ScatNoiseSTD;
        pmi.Noise.ScatNoise = ScatNoise;
        fprintf('Scattered relative noise std %e\n', ScatNoiseSTD);
    end
end

%%
%%  Measured vector norm relative noise
%%
if pmi.Noise.VecNormSNRflag
    fprint('THIS DOES NOT HANDLE MULTIPLE WAVELENGTHS YET!!!')
    VecNormSTD = norm(pmi.Fwd.PhiScat) / ...
        sqrt((length(pmi.Fwd.PhiScat) * 10^(pmi.Noise.VecNormSNR / 10)));
    TotalVar = TotalVar + VecNormSTD .^ 2;
    VecNormNoise = randn(nMeas, nLambda) .* VecNormSTD;
    pmi.PhiTotalN = pmi.PhiTotalN + VecNormNoise;
    if pmi.Debug
        pmi.Noise.VecNormNoiseSTD = VecNormNoiseSTD;
        pmi.Noise.VecNormNoise = VecNormNoise;
        fprintf('Measured data norm relative noise std %e\n', max(VecNormSTD));
    end
end

if pmi.Debug
    pmi.Noise.TotalVar = TotalVar;
end

%%
%%  Compute the weighted system for to whiten the noise
%%
pmi.Inv.Aw = zeros(size(pmi.Inv.A));
pmi.PhiTotalNw = zeros(size(pmi.PhiTotalN));
if pmi.Noise.SrcSNRflag
    if pmi.Debug
        disp('Weighting for non-white noise');
    end
    pmi.Noise.w = sqrt(TotalVar) .^ -1;
    pmi.Inv.Aw = rowscale(pmi.Inv.A, pmi.Noise.w);    
    pmi.PhiTotalNw = pmi.Noise.w .* pmi.PhiTotalN;

else
    if pmi.Debug
        disp('Uniform noise: No weighting applied');
    end
    pmi.Noise.w = ones(size(pmi.PhiTotalN));
    pmi.Inv.Aw = pmi.Inv.A;
    pmi.PhiTotalNw = pmi.PhiTotalN;
end

pmi.Recon.flgNeedFullSVD = 1;
pmi.Recon.flgNeedEconSVD = 1;
