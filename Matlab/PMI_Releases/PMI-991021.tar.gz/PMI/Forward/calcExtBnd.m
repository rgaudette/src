%calcExtBnd     Calculate the extrapolated boundary distance.
%
%   dBnd = calcExtBnd(idxRefr, mu_sp)
%
%   dBnd        The distance to the extrapolated boundary.
%
%   idxRefr     The index of refraction for the diffuse medium.
%
%   mu_sp       The reduced scattering coefficient for the diffuse medium.
%
%
%   calcExtBnd returns the distance to the extrapolated boundary from a
%   air-diffuse medium interface.  This is calculated using the approach
%   described in:
%
%    Boundary conditions for the diffusion equation in radiative transfer
%    Haskell et. al.,  J. Opt. Soc. Am - A   Vol. 11, No. 10,  Oct 1994
%    pg 2727 - 2741
%
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 17:39:56 $
%
%  $Revision: 3.0 $
%
%  $Log: calcExtBnd.m,v $
%  Revision 3.0  1999/06/17 17:39:56  rjg
%  Initial Revision for PMI 3.0
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dBnd = calcExtBnd(idxRefr, mu_sp)

%%
%%  Reff is a linear fit to the table on p. 2731
%%
Reff = (0.493-0.431) / (1.40 - 1.33) * idxRefr - 0.747;
dBnd = 2/3 * (1 + Reff) / (1 - Reff) / mu_sp;
