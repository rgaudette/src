%rbFwdBoundary     Boundary selector radio button control function.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: rbFwdBoundary.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rbFwdBoundary(str)

UIHandles = get(gcf, 'UserData');

switch lower(str)
case {'infinite', 'inf'}
    set(UIHandles.Fwd_SemiInfinite, 'value', 0);
    set(UIHandles.Fwd_InfMedium, 'value', 1);
case {'semi-infinite', 'semi', 'extrapolated'}
    set(UIHandles.Fwd_InfMedium, 'value', 0);
    set(UIHandles.Fwd_SemiInfinite, 'value', 1);
end
