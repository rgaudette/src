%btnCopyFwdData Copy the forward model to the inverse model.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: btnCopyFwdData.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function btnCopyFwdData

UIHandles = get(gcf, 'UserData');

pmi = getFwdModelInfo;
if isfield(pmi.Fwd, 'nu')
    set(UIHandles.Inv_idxRefr, 'string',  vec2str(3.0E10 ./ pmi.Fwd.nu));
else
    set(UIHandles.Inv_idxRefr, 'string',  vec2str(3.0E10 ./ pmi.Fwd.v));
end
set(UIHandles.Inv_g, 'string', vec2str(pmi.Fwd.g));
set(UIHandles.Inv_Mu_s, 'string', vec2str(pmi.Fwd.Mu_sp ./ (1 - pmi.Fwd.g)));
set(UIHandles.Inv_Mu_a, 'string', vec2str(pmi.Fwd.Mu_a));
if isfield(pmi.Fwd, 'Lambda')
    set(UIHandles.Inv_Lambda, 'string', vec2str(pmi.Fwd.Lambda))
end
rbInvBoundary(pmi.Fwd.Boundary.Geometry);


%%
%%  Source & Detector Data
%%
set(UIHandles.Inv_SrcXPos, 'string', uvec2str(pmi.Fwd.Src.X));
set(UIHandles.Inv_SrcYPos, 'string', uvec2str(pmi.Fwd.Src.Y));
set(UIHandles.Inv_SrcZPos, 'string', vec2str(pmi.Fwd.Src.Z));
set(UIHandles.Inv_DetXPos, 'string', uvec2str(pmi.Fwd.Det.X));
set(UIHandles.Inv_DetYPos, 'string', uvec2str(pmi.Fwd.Det.Y));
set(UIHandles.Inv_DetZPos, 'string', vec2str(pmi.Fwd.Det.Z));
set(UIHandles.Inv_ModFreq, 'string', vec2str(pmi.Fwd.ModFreq));

if all(pmi.Fwd.Src.Normal(1,1) == pmi.Fwd.Src.Normal(:,1)) & ...
        all(pmi.Fwd.Src.Normal(1,1) == pmi.Fwd.Src.Normal(:,1)) & ...
        all(pmi.Fwd.Src.Normal(1,1) == pmi.Fwd.Src.Normal(:,1))
    set(UIHandles.InvSrc_Normal, 'string', ...
        vec2str(pmi.Fwd.Src.Normal(1,:)));
else
    set(UIHandles.InvSrc_Normal, 'string', ...
        mat2str(pmi.Fwd.Src.Normal));
end

if all(pmi.Fwd.Src.Amplitude(1) == pmi.Fwd.Src.Amplitude(1))
    set(UIHandles.InvSrc_Amp, 'string', ...
        num2str(pmi.Fwd.Src.Amplitude(1)));
else
    set(UIHandles.InvSrc_Amp, 'string', vec2str(pmi.Fwd.Src.Amplitude));
end
if all(pmi.Fwd.Src.NA(1) == pmi.Fwd.Src.NA(1))
    set(UIHandles.InvSrc_NA, 'string', num2str(pmi.Fwd.Src.NA(1)));
else
    set(UIHandles.InvSrc_NA, 'string', vec2str(pmi.Fwd.Src.NA));
end

if all(pmi.Fwd.Det.Normal(1,1) == pmi.Fwd.Det.Normal(:,1)) & ...
        all(pmi.Fwd.Det.Normal(1,1) == pmi.Fwd.Det.Normal(:,1)) & ...
        all(pmi.Fwd.Det.Normal(1,1) == pmi.Fwd.Det.Normal(:,1))
    set(UIHandles.InvDet_Normal, 'string', ...
        vec2str(pmi.Fwd.Det.Normal(1,:)));
else
    set(UIHandles.InvDet_Normal, 'string', ...
        mat2str(pmi.Fwd.Det.Normal));
end

if all(pmi.Fwd.Det.Amplitude(1) == pmi.Fwd.Det.Amplitude(1))
    set(UIHandles.InvDet_Amp, 'string', ...
        num2str(pmi.Fwd.Det.Amplitude(1)));
else
    set(UIHandles.InvDet_Amp, 'string', vec2str(pmi.Fwd.Det.Amplitude));
end
if all(pmi.Fwd.Det.NA(1) == pmi.Fwd.Det.NA(1))
    set(UIHandles.InvDet_NA, 'string', num2str(pmi.Fwd.Det.NA(1)));
else
    set(UIHandles.InvDet_NA, 'string', vec2str(pmi.Fwd.Det.NA));
end
