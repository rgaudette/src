%tabInvProb     Make the inverse problem visible in the GUI.
%
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: tabInvProb.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function tabInvProb()

UIHandles = get(gcf, 'UserData');

set(UIHandles.vTAB1, 'visible', 'off');
set(UIHandles.vTAB2, 'visible', 'on');
set(UIHandles.InvProbTab, 'FontWeight', 'bold');
set(UIHandles.FwdProbTab, 'FontWeight', 'light');
