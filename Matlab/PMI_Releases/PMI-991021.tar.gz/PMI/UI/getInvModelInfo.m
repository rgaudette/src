%getInvModelInfo Get the geometry info from the GUI.
%
%   pmi = getInvModelInfo(pmi)
%
%   pmi         The Photon Migration Imaging data structure to fill in.  If
%               this is not present in the input argument list it will be
%               created.
%
%   getInvModelInfo extracts the inverse model info from the GUI and fills
%   in the PMI image data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: getInvModelInfo.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = getInvModelInfo(pmi)

if nargin < 1
    pmi = [];
end

%%
%%  Get the handle structure from the current figure's user data.
%%
UIHandles = get(gcf, 'UserData');

if ~isfield(pmi, 'Version')
    pmi.Version = 3;
end
if ~isfield(pmi, 'Debug')
    pmi.Debug = 0;
end


%%
%%  Medium paramters
%%
pmi.Inv.Lambda = eval(get(UIHandles.Inv_Lambda, 'string'));
nLambda = length(pmi.Inv.Lambda);

pmi.Inv.idxRefr = eval(get(UIHandles.Inv_idxRefr, 'string'));
if length(pmi.Inv.idxRefr) ~= nLambda
    warning(['Number of index of refraction parameters must match the number of' ...
             ' wavelengths']);
end
pmi.Inv.Mu_s = eval(get(UIHandles.Inv_Mu_s, 'string'));
if length(pmi.Inv.Mu_s) ~= nLambda
    warning(['Number of mu_s must match the number of' ...
             ' wavelengths']);
end

pmi.Inv.g = eval(get(UIHandles.Inv_g, 'string'));
if length(pmi.Inv.g) ~= nLambda
    warning(['Number of mean cosine angle parameters must match the number of' ...
             ' wavelengths']);
end

pmi.Inv.Mu_a = eval(get(UIHandles.Inv_Mu_a, 'string'));
if length(pmi.Inv.Mu_a) ~= nLambda
    warning(['Number of mu_a parameters must match the number of' ...
             ' wavelengths']);
end
pmi.Inv.Mu_sp = pmi.Inv.Mu_s .* (1 - pmi.Inv.g);
pmi.Inv.v = 3.0E10 ./ pmi.Inv.idxRefr;

%%
%%  Source & Detector Data
%%
pmi.Inv.Src.Type = 'uniform';
pmi.Inv.Src.X = eval(get(UIHandles.Inv_SrcXPos, 'string'));
pmi.Inv.Src.Y = eval(get(UIHandles.Inv_SrcYPos, 'string'));
pmi.Inv.Src.Z = eval(get(UIHandles.Inv_SrcZPos, 'string'));
[pos nSrc] = getOptodePos(pmi.Inv.Src);

Normal = eval(get(UIHandles.InvSrc_Normal, 'string'));
if size(Normal, 1) == 1
    pmi.Inv.Src.Normal = repmat(Normal, nSrc, 1);
else
    pmi.Inv.Src.Normal = Normal;
end

Amplitude = eval(get(UIHandles.InvSrc_Amp, 'string'));
if length(Amplitude) == 1
    pmi.Inv.Src.Amplitude = repmat(Amplitude, 1, nSrc);
else
    pmi.Inv.Src.Amplitude = Amplitude;
end

NA =  eval(get(UIHandles.InvSrc_NA, 'string'));
if length(NA) == 1
    pmi.Inv.Src.NA = repmat(NA, 1, nSrc);
else
    pmi.Inv.Src.NA = NA;
end

if get(UIHandles.Inv_InfMedium, 'value')
    pmi.Inv.Boundary.Geometry = 'Infinite';
end
if get(UIHandles.Inv_SemiInfinite, 'value')
    pmi.Inv.Boundary.Geometry = 'Semi-infinite';
end

pmi.Inv.Det.Type = 'uniform';
pmi.Inv.Det.X = eval(get(UIHandles.Inv_DetXPos, 'string'));
pmi.Inv.Det.Y = eval(get(UIHandles.Inv_DetYPos, 'string'));
pmi.Inv.Det.Z = eval(get(UIHandles.Inv_DetZPos, 'string'));;

[pos nDet] = getOptodePos(pmi.Inv.Det);

Normal = eval(get(UIHandles.InvDet_Normal, 'string'));
if size(Normal, 1) == 1
    pmi.Inv.Det.Normal = repmat(Normal, nDet, 1);
else
    pmi.Inv.Det.Normal = Normal;
end

Amplitude = eval(get(UIHandles.InvDet_Amp, 'string'));
if length(Amplitude) == 1
    pmi.Inv.Det.Amplitude = repmat(Amplitude, 1, nDet);
else
    pmi.Inv.Det.Amplitude = Amplitude;
end

NA =  eval(get(UIHandles.InvDet_NA, 'string'));
if length(NA) == 1
    pmi.Inv.Det.NA = repmat(NA, 1, nDet);
else
    pmi.Inv.Det.NA = NA;
end

pmi.Inv.ModFreq = eval(get(UIHandles.Inv_ModFreq, 'string'));

if get(UIHandles.Inv_InfMedium, 'value')
    pmi.Inv.Boundary.Geometry = 'Infinite';
end
if get(UIHandles.Inv_SemiInfinite, 'value')
    pmi.Inv.Boundary.Geometry = 'Semi-infinite';
end

%%
%%  Forward model method
%%
if get(UIHandles.Inv_Born,'value')
    pmi.Inv.Method.Type = 'Born';
    pmi.Inv.Method.Order = 1;

end
if get(UIHandles.Inv_Rytov,'value')
    pmi.Inv.Method.Type = 'Rytov';
end

%%
%%  Computation Volume Parameters
%%
XMin = eval(get(UIHandles.Inv_XMin, 'string'));
XMax = eval(get(UIHandles.Inv_XMax, 'string'));
XStep = eval(get(UIHandles.Inv_XStep, 'string'));
YMin = eval(get(UIHandles.Inv_YMin, 'string'));
YMax = eval(get(UIHandles.Inv_YMax, 'string'));
YStep = eval(get(UIHandles.Inv_YStep, 'string'));
ZMin = eval(get(UIHandles.Inv_ZMin, 'string'));
ZMax = eval(get(UIHandles.Inv_ZMax, 'string'));
ZStep = eval(get(UIHandles.Inv_ZStep, 'string'));
pmi.Inv.CompVol.Type = 'uniform';
pmi.Inv.CompVol.X = [XMin:XStep:XMax];
pmi.Inv.CompVol.Y = [YMin:YStep:YMax];
pmi.Inv.CompVol.Z = [ZMin:ZStep:ZMax];
pmi.Inv.CompVol.XStep = XStep;
pmi.Inv.CompVol.YStep = YStep;
pmi.Inv.CompVol.ZStep = ZStep;

