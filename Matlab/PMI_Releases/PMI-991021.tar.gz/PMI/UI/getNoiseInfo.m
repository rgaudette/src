%getNoiseInfo   Get the noise model info from the GUI.
%
%   pmi = getNoiseInfo(pmi)
%
%   pmi         The Photon Migration Imaging data structure to fill in.  If
%               this is not present in the input argument list it will be
%               created.
%
%   getNoiseInfo extracts the noise model info from the GUI and fills
%   in the PMI data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: getNoiseInfo.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = getNoiseInfo(pmi)

if nargin < 1
    pmi = [];
end

%%
%%  Get the handle structure from the current figure's user data.
%%
UIHandles = get(gcf, 'UserData');

%%
%%  Noise level parameters
%%
pmi.Noise.SrcSNRflag = get(UIHandles.SrcSNRflag,'value');
temp = get(UIHandles.SrcSNR,'string');
if ~isempty(temp)
    pmi.Noise.SrcSNR = eval(get(UIHandles.SrcSNR, 'string'));
end

pmi.Noise.DetSNRflag = get(UIHandles.DetSNRflag,'value');
temp = get(UIHandles.DetSNR,'string');
if ~isempty(temp)
    pmi.Noise.DetSNR = eval(get(UIHandles.DetSNR, 'string'));
end

pmi.Noise.ScatSNRflag = get(UIHandles.ScatSNRflag,'value');
temp = get(UIHandles.ScatSNR,'string');
if ~isempty(temp)
    pmi.Noise.ScatSNR = eval(get(UIHandles.ScatSNR, 'string'));
end

pmi.Noise.VecNormSNRflag = get(UIHandles.VecNormSNRflag,'value');
temp = get(UIHandles.VecNormSNR,'string');
if ~isempty(temp)
    pmi.Noise.VecNormSNR = eval(get(UIHandles.VecNormSNR, 'string'));
end


