%doInvCalc      Calculate the forward system matrix for the inverse problem
%
%   This script extracts the current system parameters from the GUI Slab
%   image interface and calculates the forward matrix for the inverse
%   problem specified by the parameters as well as the incident detector
%   fluence.
%
%   Calls: getInvModelInfo, getinvmat
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/10/19 22:15:09 $
%
%  $Revision: 3.1 $
%
%  $Log: doInvCalc.m,v $
%  Revision 3.1  1999/10/19 22:15:09  rjg
%  Fixed DOS line feeds.
%
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%  Revision 3.0  1999/06/17 21:45:42  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%%  Set the busy light to red
%%
UIHandles = get(gcf, 'UserData');
set(UIHandles.hLight, 'Color', [1 0 0]);
drawnow;

%%
%%  Get all of the measurement parameters from GUI
%%
if ~exist('dsPMI', 'var')
    dsPMI = [];
end
dsPMI = getInvModelInfo(dsPMI);
    

%%
%%  Calculate the forward matrix and incident fields returning all
%%  results in data structure.
%%
dsPMI.Inv = genFwdMat(dsPMI.Inv, dsPMI.Debug);

%%
%%  Reweight the forward matrix if the weighting vector exists
%%
if isfield(dsPMI, 'Noise')
    if isfield(dsPMI.Noise, 'w')
        if dsPMI.Noise.SrcSNRflag
            if dsPMI.Debug
                disp('Re-Weighting for non-white noise');
            end
            dsPMI.Inv.Aw = rowscale(dsPMI.Inv.A, dsPMI.Noise.w);
        else
            if dsPMI.Debug
                disp(['Uniform noise: No weighting applied, dsPMI.Inv.Aw' ...
                      ' updated']);
                
            end
            dsPMI.Inv.Aw = dsPMI.Inv.A;
        end
    end
end
dsPMI.Recon.flgNeedFullSVD = 1;
dsPMI.Recon.flgNeedEconSVD = 1;
  
set(UIHandles.hLight, 'Color', [0 1 0]);
drawnow;
clear UIHandles;
