%rbInvMethod    Inverse method radio button selection.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: rbInvMethod.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rbInvMethod(value)
UIHandles = get(gcf, 'UserData');

switch value

case 'Born'
    set(UIHandles.Inv_Rytov, 'value', 0);
    set(UIHandles.Inv_Born, 'value', 1);

case 'Rytov'
    set(UIHandles.Inv_Born, 'value', 0);
    set(UIHandles.Inv_Rytov, 'value', 1);
end
