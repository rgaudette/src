%GETALL         Return all of the system parameter from the PMI GUI.
%
%   pmi = getall;
%
%   pmi        The PMI structure containing all of the parameters.
%
%
%   GETALL queries each known edit or radio button control to fill in the
%   all of the members of the data structure.  The GUI must be the current
%   figure.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: getall.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%  Revision 2.1  1998/08/20 20:28:55  rjg
%  Preserves any computed data if the slab image data structure is passed on the
%  command line.
%
%  Revision 2.0  1998/08/05 16:36:48  rjg
%  Broke up into seperate functions for handling of V2.0 data
%  structure.
%
%  Revision 1.6  1998/07/30 19:58:35  rjg
%  Removed SIdefines codes, uses string now.
%  Added parameters for the three noise models
%  Added parameters for TCG
%
%  Revision 1.5  1998/06/03 16:39:02  rjg
%  Uses SIdefines codes
%  MTSVD parameters
%
%  Revision 1.4  1998/04/29 16:10:32  rjg
%  Fixed else statment reporting ans, changed to elseif.
%  
%  Added comments.
%
%  Revision 1.3  1998/04/29 15:15:28  rjg
%  Added visualization techniques members.
%
%  Revision 1.2  1998/04/28 20:26:12  rjg
%  Added to help.
%
%  Revision 1.1  1998/04/28 20:24:42  rjg
%  Initial revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function pmi = getall(pmi)

if nargin < 1
    pmi = [];
end
pmi = getMetaData(pmi);
pmi = getFwdModelInfo(pmi);
pmi = getInvModelInfo(pmi);
pmi = getObjectInfo(pmi);
pmi = getNoiseInfo(pmi);
pmi = getRecInfo(pmi);
pmi = getVisInfo(pmi);