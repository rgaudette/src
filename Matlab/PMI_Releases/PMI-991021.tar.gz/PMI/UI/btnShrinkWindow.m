%btnShrinkWindow  Shrink the GUI window to just the buttons.
%
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:46:56 $
%
%  $Revision: 3.0 $
%
%  $Log: btnShrinkWindow.m,v $
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%  Revision 3.0  1999/06/17 21:45:42  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function btnShrinkWindow

UIHandles = get(gcf, 'UserData');

if strcmp(get(UIHandles.hBtnShrink, 'String'), 'Shrink Window')
    pos = get(gcf, 'position');
    pos(3) = UIHandles.BtnWindow(1);
    pos(4) = UIHandles.BtnWindow(2);
    set(UIHandles.hBtnShrink, 'String', 'Expand')
else
    pos = get(gcf, 'position');
    pos(3) = UIHandles.FullWindow(1);
    pos(4) = UIHandles.FullWindow(2);
    set(UIHandles.hBtnShrink, 'String', 'Shrink Window')
end
set(gcf, 'Position', pos);
