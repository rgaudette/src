%SETALL         Set all of the system parameter in the PMI GUI.
%
%   getall(pmi, hFig)
%
%   pmi         The structure containing all of the PMI parameters.
%
%   hFig        The handle of the GUI figure.
%
%   SETALL setall of the modifiable values in the GUI to the values present
%   in the structure pmi.
%
%   Calls: rbBoundary, rbDataSource, rbRecon, vec2str, uvec2str.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/10/19 22:18:08 $
%
%  $Revision: 3.1 $
%
%  $Log: setall.m,v $
%  Revision 3.1  1999/10/19 22:18:08  rjg
%  Rudimentary handling of 'list' type source and detector positions.  Just writes
%  each column of the .Pos vector in the appropriate window.
%
%  Revision 3.0  1999/06/17 21:46:56  rjg
%  Initial PMI 3.0 revision
%
%  Revision 2.3  1999/02/05 20:47:31  rjg
%  Handles conditional setting of object parameters.
%
%  Revision 2.2  1998/08/12 19:02:20  rjg
%  Added forgotten setting of the visualization plane.
%
%  Revision 2.1  1998/08/07 21:33:03  rjg
%  Change ZIndices to PlaneIndices to reflect the ability to slice in all
%  three dimensions.
%
%  Revision 2.0  1998/08/05 18:40:16  rjg
%  Handles CompVol structure of SlabImage data structure.
%  Added Z pos for source and detctors.
%  Added amplitude for sources.
%
%  Revision 1.5  1998/07/30 20:02:56  rjg
%  Removed SIdefines codes, uses string now.
%  Parameters for all three noise models
%  Parameters for TCG
%
%  Revision 1.4  1998/06/05 17:39:13  rjg
%  Uniform vector, vectors and scalar are now handled within the (u)vec2str
%  functions
%
%  Revision 1.3  1998/06/03 16:45:31  rjg
%  Uses SIdefines codes
%  Medium parameters can now be vectors for multiple wavelengths
%  SphereDelta can now be a vector for multple spheres
%  MTSVD implementation
%
%  Revision 1.2  1998/04/29 15:17:16  rjg
%  Added visualization techniques members and comments.
%
%  Revision 1.1  1998/04/28 20:33:08  rjg
%  Initial revision
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function setall(pmi, hFig)

UIHandles = get(hFig, 'UserData');
set(0, 'CurrentFigure', hFig);


%%
%%  Forward Model Parameters
%%
if isfield(pmi, 'Fwd')
    %%
    %%  Medium Parametes
    %%
    if isfield(pmi.Fwd, 'nu')
        set(UIHandles.Fwd_idxRefr, 'string',  vec2str(3.0E10 ./ pmi.Fwd.nu));
    else
        set(UIHandles.Fwd_idxRefr, 'string',  vec2str(3.0E10 ./ pmi.Fwd.v));
    end
    set(UIHandles.Fwd_g, 'string', vec2str(pmi.Fwd.g));
    set(UIHandles.Fwd_Mu_s, 'string', vec2str(pmi.Fwd.Mu_sp ./ (1 - pmi.Fwd.g)));
    set(UIHandles.Fwd_Mu_a, 'string', vec2str(pmi.Fwd.Mu_a));
    if isfield(pmi.Fwd, 'Lambda')
        set(UIHandles.Fwd_Lambda, 'string', vec2str(pmi.Fwd.Lambda))
    end
    
    rbFwdBoundary(pmi.Fwd.Boundary.Geometry);

    %%
    %%  Computation volume
    %%
    set(UIHandles.Fwd_XMin, 'string', num2str(min(pmi.Fwd.CompVol.X)));
    set(UIHandles.Fwd_XMax, 'string', num2str(max(pmi.Fwd.CompVol.X)));
    set(UIHandles.Fwd_XStep, 'string', num2str(pmi.Fwd.CompVol.XStep));
    set(UIHandles.Fwd_YMin, 'string', num2str(min(pmi.Fwd.CompVol.Y)));
    set(UIHandles.Fwd_YMax, 'string', num2str(max(pmi.Fwd.CompVol.Y)));
    set(UIHandles.Fwd_YStep, 'string', num2str(pmi.Fwd.CompVol.YStep));
    set(UIHandles.Fwd_ZMin, 'string', num2str(min(pmi.Fwd.CompVol.Z)));
    set(UIHandles.Fwd_ZMax, 'string', num2str(max(pmi.Fwd.CompVol.Z)));
    set(UIHandles.Fwd_ZStep, 'string', num2str(pmi.Fwd.CompVol.ZStep));
        
        
    %%
    %%  Source & Detector Data
    %%
    if strcmp(pmi.Fwd.Src.Type, 'uniform')
        set(UIHandles.Fwd_SrcXPos, 'string', uvec2str(pmi.Fwd.Src.X));
        set(UIHandles.Fwd_SrcYPos, 'string', uvec2str(pmi.Fwd.Src.Y));
        set(UIHandles.Fwd_SrcZPos, 'string', vec2str(pmi.Fwd.Src.Z));
    else
        set(UIHandles.Fwd_SrcXPos, 'string', vec2str(pmi.Fwd.Src.Pos(:,1)));
        set(UIHandles.Fwd_SrcYPos, 'string', vec2str(pmi.Fwd.Src.Pos(:,2)));
        set(UIHandles.Fwd_SrcZPos, 'string', vec2str(pmi.Fwd.Src.Pos(:,3)));
    end
    if strcmp(pmi.Fwd.Det.Type, 'uniform')
        set(UIHandles.Fwd_DetXPos, 'string', uvec2str(pmi.Fwd.Det.X));
        set(UIHandles.Fwd_DetYPos, 'string', uvec2str(pmi.Fwd.Det.Y));
        set(UIHandles.Fwd_DetZPos, 'string', vec2str(pmi.Fwd.Det.Z));
    else
        set(UIHandles.Fwd_DetXPos, 'string', vec2str(pmi.Fwd.Det.Pos(:,1)));
        set(UIHandles.Fwd_DetYPos, 'string', vec2str(pmi.Fwd.Det.Pos(:,2)));
        set(UIHandles.Fwd_DetZPos, 'string', vec2str(pmi.Fwd.Det.Pos(:,3)));
    end
    
    set(UIHandles.Fwd_ModFreq, 'string', vec2str(pmi.Fwd.ModFreq));
        
    if all(pmi.Fwd.Src.Normal(1,1) == pmi.Fwd.Src.Normal(:,1)) & ...
            all(pmi.Fwd.Src.Normal(1,1) == pmi.Fwd.Src.Normal(:,1)) & ...
            all(pmi.Fwd.Src.Normal(1,1) == pmi.Fwd.Src.Normal(:,1))
        set(UIHandles.FwdSrc_Normal, 'string', ...
            vec2str(pmi.Fwd.Src.Normal(1,:)));
    else
        set(UIHandles.FwdSrc_Normal, 'string', ...
            mat2str(pmi.Fwd.Src.Normal));
    end
    if all(pmi.Fwd.Src.Amplitude(1) == pmi.Fwd.Src.Amplitude(1))
        set(UIHandles.FwdSrc_Amp, 'string', ...
            num2str(pmi.Fwd.Src.Amplitude(1)));
    else
        set(UIHandles.FwdSrc_Amp, 'string', vec2str(pmi.Fwd.Src.Amplitude));
    end
    if all(pmi.Fwd.Src.NA(1) == pmi.Fwd.Src.NA(1))
        set(UIHandles.FwdSrc_NA, 'string', num2str(pmi.Fwd.Src.NA(1)));
    else
        set(UIHandles.FwdSrc_NA, 'string', vec2str(pmi.Fwd.Src.NA));
    end

    if all(pmi.Fwd.Det.Normal(1,1) == pmi.Fwd.Det.Normal(:,1)) & ...
            all(pmi.Fwd.Det.Normal(1,1) == pmi.Fwd.Det.Normal(:,1)) & ...
            all(pmi.Fwd.Det.Normal(1,1) == pmi.Fwd.Det.Normal(:,1))
        set(UIHandles.FwdDet_Normal, 'string', ...
            vec2str(pmi.Fwd.Det.Normal(1,:)));
    else
        set(UIHandles.FwdDet_Normal, 'string', ...
            mat2str(pmi.Fwd.Det.Normal));
    end

    if all(pmi.Fwd.Det.Amplitude(1) == pmi.Fwd.Det.Amplitude(1))
        set(UIHandles.FwdDet_Amp, 'string', ...
            num2str(pmi.Fwd.Det.Amplitude(1)));
    else
        set(UIHandles.FwdDet_Amp, 'string', vec2str(pmi.Fwd.Det.Amplitude));
    end
    if all(pmi.Fwd.Det.NA(1) == pmi.Fwd.Det.NA(1))
        set(UIHandles.FwdDet_NA, 'string', num2str(pmi.Fwd.Det.NA(1)));
    else
        set(UIHandles.FwdDet_NA, 'string', vec2str(pmi.Fwd.Det.NA));
    end
    
    %%
    %%  Forward model method
    %%
    rbFwdMethod(pmi.Fwd.Method.Type);

    if strcmp(pmi.Fwd.Method.Type, 'Born')
        set(UIHandles.Fwd_Order, 'string', num2str(pmi.Fwd.Method.Order));
    end

    if strcmp(pmi.Fwd.Method.Type, 'Spherical')
        set(UIHandles.Fwd_Order, 'string', num2str(pmi.Fwd.Method.Order));
    end

end

%%
%%  Inverse Model Parameters
%%
if isfield(pmi, 'Inv')
    %%
    %%  Medium Parameters
    %%
    if isfield(pmi.Inv, 'nu')
        set(UIHandles.Inv_idxRefr, 'string',  vec2str(3.0E10 ./ pmi.Inv.nu));
    else
        set(UIHandles.Inv_idxRefr, 'string',  vec2str(3.0E10 ./ pmi.Inv.v));
    end
    set(UIHandles.Inv_g, 'string', vec2str(pmi.Inv.g));
    set(UIHandles.Inv_Mu_s, 'string', vec2str(pmi.Inv.Mu_sp ./ (1 - pmi.Inv.g)));
    set(UIHandles.Inv_Mu_a, 'string', vec2str(pmi.Inv.Mu_a));
    if isfield(pmi.Inv, 'Lambda')
        set(UIHandles.Inv_Lambda, 'string', vec2str(pmi.Inv.Lambda))
    end
    rbInvBoundary(pmi.Inv.Boundary.Geometry);

    %%
    %%  Computation volume
    %%
    set(UIHandles.Inv_XMin, 'string', num2str(min(pmi.Inv.CompVol.X)));
    set(UIHandles.Inv_XMax, 'string', num2str(max(pmi.Inv.CompVol.X)));
    set(UIHandles.Inv_XStep, 'string', num2str(pmi.Inv.CompVol.XStep));
    set(UIHandles.Inv_YMin, 'string', num2str(min(pmi.Inv.CompVol.Y)));
    set(UIHandles.Inv_YMax, 'string', num2str(max(pmi.Inv.CompVol.Y)));
    set(UIHandles.Inv_YStep, 'string', num2str(pmi.Inv.CompVol.YStep));
    set(UIHandles.Inv_ZMin, 'string', num2str(min(pmi.Inv.CompVol.Z)));
    set(UIHandles.Inv_ZMax, 'string', num2str(max(pmi.Inv.CompVol.Z)));
    set(UIHandles.Inv_ZStep, 'string', num2str(pmi.Inv.CompVol.ZStep));

    %%
    %%  Source & Detector Data
    %%
    if strcmp(pmi.Fwd.Src.Type, 'uniform')        
        set(UIHandles.Inv_SrcXPos, 'string', uvec2str(pmi.Inv.Src.X));
        set(UIHandles.Inv_SrcYPos, 'string', uvec2str(pmi.Inv.Src.Y));
        set(UIHandles.Inv_SrcZPos, 'string', vec2str(pmi.Inv.Src.Z));
    else
        set(UIHandles.Inv_SrcXPos, 'string', vec2str(pmi.Inv.Src.Pos(:,1)));
        set(UIHandles.Inv_SrcYPos, 'string', vec2str(pmi.Inv.Src.Pos(:,2)));
        set(UIHandles.Inv_SrcZPos, 'string', vec2str(pmi.Inv.Src.Pos(:,3)));
    end

    if strcmp(pmi.Inv.Det.Type, 'uniform')
        set(UIHandles.Inv_DetXPos, 'string', uvec2str(pmi.Inv.Det.X));
        set(UIHandles.Inv_DetYPos, 'string', uvec2str(pmi.Inv.Det.Y));
        set(UIHandles.Inv_DetZPos, 'string', vec2str(pmi.Inv.Det.Z));
    
    else
        set(UIHandles.Inv_DetXPos, 'string', vec2str(pmi.Inv.Det.Pos(:,1)));
        set(UIHandles.Inv_DetYPos, 'string', vec2str(pmi.Inv.Det.Pos(:,2)));
        set(UIHandles.Inv_DetZPos, 'string', vec2str(pmi.Inv.Det.Pos(:,3)));
    end

    set(UIHandles.Inv_ModFreq, 'string', vec2str(pmi.Inv.ModFreq));

    if all(pmi.Inv.Src.Normal(1,1) == pmi.Inv.Src.Normal(:,1)) & ...
            all(pmi.Inv.Src.Normal(1,1) == pmi.Inv.Src.Normal(:,1)) & ...
            all(pmi.Inv.Src.Normal(1,1) == pmi.Inv.Src.Normal(:,1))
        set(UIHandles.InvSrc_Normal, 'string', ...
            vec2str(pmi.Inv.Src.Normal(1,:)));
    else
        set(UIHandles.InvSrc_Normal, 'string', ...
            mat2str(pmi.Inv.Src.Normal));
    end

    if all(pmi.Inv.Src.Amplitude(1) == pmi.Inv.Src.Amplitude(1))
        set(UIHandles.InvSrc_Amp, 'string', ...
            num2str(pmi.Inv.Src.Amplitude(1)));
    else
        set(UIHandles.InvSrc_Amp, 'string', vec2str(pmi.Inv.Src.Amplitude));
    end
    if all(pmi.Inv.Src.NA(1) == pmi.Inv.Src.NA(1))
        set(UIHandles.InvSrc_NA, 'string', num2str(pmi.Inv.Src.NA(1)));
    else
        set(UIHandles.InvSrc_NA, 'string', vec2str(pmi.Inv.Src.NA));
    end

    if all(pmi.Inv.Det.Normal(1,1) == pmi.Inv.Det.Normal(:,1)) & ...
            all(pmi.Inv.Det.Normal(1,1) == pmi.Inv.Det.Normal(:,1)) & ...
            all(pmi.Inv.Det.Normal(1,1) == pmi.Inv.Det.Normal(:,1))
        set(UIHandles.InvDet_Normal, 'string', ...
            vec2str(pmi.Inv.Det.Normal(1,:)));
    else
        set(UIHandles.InvDet_Normal, 'string', ...
            mat2str(pmi.Inv.Det.Normal));
    end

    if all(pmi.Inv.Det.Amplitude(1) == pmi.Inv.Det.Amplitude(1))
        set(UIHandles.InvDet_Amp, 'string', ...
            num2str(pmi.Inv.Det.Amplitude(1)));
    else
        set(UIHandles.InvDet_Amp, 'string', vec2str(pmi.Inv.Det.Amplitude));
    end
    if all(pmi.Inv.Det.NA(1) == pmi.Inv.Det.NA(1))
        set(UIHandles.InvDet_NA, 'string', num2str(pmi.Inv.Det.NA(1)));
    else
        set(UIHandles.InvDet_NA, 'string', vec2str(pmi.Inv.Det.NA));
    end

    %%
    %%  Forward model method
    %%
    rbInvMethod(pmi.Inv.Method.Type);
end

%%
%%  Noise Model Parameters
%%
if isfield(pmi, 'Noise')
    %%
    %%  Noise level controls
    %%
    if pmi.Noise.SrcSNRflag
        set(UIHandles.SrcSNRflag, 'value', 1);
        set(UIHandles.SrcSNR, 'string', num2str(pmi.Noise.SrcSNR));
    else
        set(UIHandles.SrcSNRflag, 'value', 0);
        if isfield(pmi.Noise, 'SrcSNR')
            set(UIHandles.SrcSNR, 'string', num2str(pmi.Noise.SrcSNR));
        end
    end    
    if pmi.Noise.DetSNRflag
        set(UIHandles.DetSNRflag, 'value', 1);
        set(UIHandles.DetSNR, 'string', num2str(pmi.Noise.DetSNR));
    else
        set(UIHandles.DetSNRflag, 'value', 0);
        if isfield(pmi.Noise, 'DetSNR')
            set(UIHandles.DetSNR, 'string', num2str(pmi.Noise.DetSNR));
        end
    end

    if pmi.Noise.ScatSNRflag
        set(UIHandles.ScatSNRflag, 'value', 1);
        set(UIHandles.ScatSNR, 'string', num2str(pmi.Noise.ScatSNR));
    else
        set(UIHandles.ScatSNRflag, 'value', 0);
        if isfield(pmi.Noise, 'ScatSNR')
            set(UIHandles.ScatSNR, 'string', num2str(pmi.Noise.ScatSNR));
        end
    end    

    if isfield(pmi.Noise, 'VecNormSNRflag')
        set(UIHandles.VecNormSNRflag, 'value', pmi.Noise.VecNormSNRflag);
    end
    if isfield(pmi.Noise, 'VecNormSNR')
        set(UIHandles.VecNormSNR, 'string', num2str(pmi.Noise.VecNormSNR));
    end
end

%%
%%  Object Model Parameters
%%
if isfield(pmi, 'Object')
    nObjects = length(pmi.Object);
    nSphere = 0;
    nBlock = 0;
    for i = 1:nObjects
        if strcmp(pmi.Object{i}.Type, 'sphere')
            nSphere = nSphere + 1;
            SphereCtr(nSphere,:) = pmi.Object{i}.Pos;
            SphereRad(nSphere) = pmi.Object{i}.Radius;
            SphereMu_a(nSphere,:) = pmi.Object{i}.Mu_a;
        end
        if strcmp(pmi.Object{i}.Type, 'block')
            nBlock = nBlock + 1;
            BlockCtr(nBlock,:) = pmi.Object{i}.Pos;
            BlockDims(nBlock,:) = pmi.Object{i}.Dims;
            BlockMu_a(nBlock,:) = pmi.Object{i}.Mu_a;
        end
    end
    if nSphere > 0
        set(UIHandles.SphereCtr, 'string', mat2str(SphereCtr));
        set(UIHandles.SphereRad, 'string', vec2str(SphereRad));
        set(UIHandles.SphereDelta, 'string', mat2str(SphereMu_a));
    end
    if nBlock > 0
        set(UIHandles.BlockCtr, 'string', mat2str(BlockCtr));
        set(UIHandles.BlockDims, 'string', mat2str(BlockDims));
        set(UIHandles.BlockDelta, 'string', mat2str(BlockMu_a));
    end
end

%%
%%  Reoncstruction Parameters
%%
if isfield(pmi, 'Recon')
    %%
    %%  Reconstruction algorithm
    %%
    rbRecon(pmi.Recon.ReconAlg)
    switch pmi.Recon.ReconAlg
        case 'Back Projection'
        case 'Min. Norm'
        case 'ART'
            set(UIHandles.ARTnIter, 'string', num2str(pmi.Recon.ARTnIter));
        case 'SIRT'
            set(UIHandles.SIRTnIter, 'string', num2str(pmi.Recon.SIRTnIter));
        case 'TSVD'
            set(UIHandles.TSVDnSV, 'string', num2str(pmi.Recon.TSVDnSV));
        case 'MTSVD'
            set(UIHandles.MTSVDnSV, 'string', num2str(pmi.Recon.MTSVDnSV));
            set(UIHandles.MTSVDLambda, 'string', ...
                num2str(pmi.Recon.MTSVDLambda));
        case 'TCG'
            set(UIHandles.TCGnIter, 'string', num2str(pmi.Recon.TCGnIter));
        otherwise
            error(['Unknown reconstruction technique: ' pmi.Recon.ReconAlg]);
    end
end

%%
%%  Visualization Parameters
%%
if isfield(pmi, 'Visualize')
    %%
    %%  Visualization technique
    %%
    rbVisPlane(pmi.Visualize.VisPlane);
    set(UIHandles.PlaneIndices, 'string', vec2str(pmi.Visualize.PlaneIndices));
    set(UIHandles.LayoutVector, 'string', vec2str(pmi.Visualize.LayoutVector));

    rbVisualize(pmi.Visualize.Type)
    if strcmp(pmi.Visualize.Type, 'contour')
        set(UIHandles.nCLines, 'string', int2str(pmi.Visualize.nCLines));
    end

    rbColormap(pmi.Visualize.CMap);
    rbColorRange(pmi.Visualize.CRange);
    if strcmp(pmi.Visualize.CRange, 'fixed')
        set(UIHandles.CRangeVal, 'string', vec2str(pmi.Visualize.CRangeVal));
    end
end
