%VECNORM        Compute the norm of the columns vectors in an array.
%
%   xnorm = vecnorm(array, p)
%
%   xnorm       The norm of each column in the array.
%
%   array       The array to be analyzed.
%
%   p           OPTIONAL: Compute the pth norm instead of the 2-norm.
%
%
%   VECNORM loops over each column in array calculating specfied norm of each
%   column. 
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author:$
%
%  $Date:$
%
%  $Revision:$
%
%  $Log:$
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function xnorm = vecnorm(array, p)

if nargin < 2
    p = 2;
end

%%
%%  get the size of the array and pre-allocate the result
%%
nDims = ndims(array);
nCols = size(array, 2);
if nDims > 2
    error('This functionality not yet implemented, bug Rick!');
else
    xnorm = zeros(1,size(array,2));
end

for iCol = 1:nCols
    xnorm(iCol) = norm(array(:, iCol), p);
end
