%OPAPSC         Optimum a priori scaling coeffiecient
%
%   alpha = opapsc(XTrue, XEst);
%
%   alpha       The optimum scaling coefficient.
%
%   XTrue       The true vector.
%
%   XEst        The estimated vector
%
%
%   OPAPSC solves the minimimzation problem
%
%       alpha = argmin(||XTrue - alpha*XEst||)
%
%
%   Calls: none.
%
%   Bugs: Seems to work for complex vector but I only worked it out in terms of
%   the SVD.  I am not sure that this holds in all complex cases.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author:$
%
%  $Date:$
%
%  $Revision:$
%
%  $Log:$
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function alpha = opapsc(XTrue, XEst);

alpha = (XEst' * XTrue) / (XEst' * XEst);

