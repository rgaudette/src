%MAT2STR        Convert a vector to a string.
%
%   str = mat2str(vec)
%
%   str         The resultant string.
%
%   vec         The vector to be converted.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:18:09 $
%
%  $Revision: 3.0 $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function str = mat2str(vec)

nRows = size(vec,1);
nCols = size(vec,2);
if nElem == 1
    str = num2str(vec);
    return;
end
if nRows == 1
    str = vec2str(vec);
end

str = '[';
for iRow = 1:Rows
    for iCol = 1:nCols
        str = [ str num2str(vec(iRow, iCol)) ' '];
    end
    str = [ str ';' ];
end
str = [str ']' ];

