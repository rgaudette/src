%cleanInvSys    Delete the forward system matrix from the PMI data structure.
%
%   pmi = cleanInvSys(pmi);
%
%   pmi          The PMI data structure to operate upon.
%
%
%   cleanInvSys removes inverse system to matrix to conserve memory.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:18:09 $
%
%  $Revision: 3.0 $
%
%  $Log: cleanInvSys.m,v $
%  Revision 3.0  1999/06/17 21:18:09  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = cleanInvSys(pmi);

if isfield(pmi.Inv, 'A')
    pmi.Inv = rmfield(pmi.Inv, 'A');
end
if isfield(pmi.Inv, 'Aw')
    pmi.Inv = rmfield(pmi.Inv, 'Aw');
end


