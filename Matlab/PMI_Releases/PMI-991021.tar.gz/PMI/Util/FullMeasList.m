%FullMeasList   Create a full measurement list in standard form.
%
%   MeasList = FullMeasList(nDet, nSrc, nFreq, nLambda)
%
%   MeasList    The MeasList matrix.
%
%   nDet, nSrc, nFreq, nLambda  The number of each measurement parameter for the
%                               measurement list.
%
%   FullMeasList returns a PMI Measurement List field specfying that all
%   detectors are cycled through first, then all sources then all frequencies
%   then finally all wavelengths.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1999/06/17 21:18:09 $
%
%  $Revision: 3.0 $
%
%  $Log: FullMeasList.m,v $
%  Revision 3.0  1999/06/17 21:18:09  rjg
%  Initial PMI 3.0 revision
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function MeasList = FullMeasList(nDet, nSrc, nFreq, nLambda)
%%
%%  Create the full MeasList matrix
%%
DOrder = repmat([1:nDet]', nSrc*nFreq*nLambda, 1);
tmp = repmat([1:nSrc], nDet, 1);
tmp = tmp(:);
SOrder = repmat(tmp, nFreq*nLambda, 1);
tmp = repmat([1:nFreq], nDet*nSrc, 1);
tmp = tmp(:);
FOrder = repmat(tmp, nLambda, 1);
tmp = repmat([1:nLambda], nDet*nSrc*nFreq, 1);
LOrder = tmp(:);

MeasList = [DOrder SOrder FOrder LOrder];
