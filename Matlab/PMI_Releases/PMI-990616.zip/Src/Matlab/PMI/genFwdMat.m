%GenFwdMat      Generate the forward matrix from a PMI Model data structure.
%
%   pmiModel = genFwdMat(pmiModel, Debug);
%
%   pmiModel    The Model data structure to updated.
%
%   Debug       The Debug level to execute.
%
%   GenFwdMat generates the forward matrix and incident field from the
%   parameters present in the slab image data structure.  The results are
%   placed in the data structure as the fields A and PhiInc
%   respectively.  Note that this routine automatically moves the diffuse
%   source positions one mean free path into the medium from the positions
%   supplied in pmiModel.
%
%   Calls: none.
%
%   Bugs: assumes diffuse medium exists in the -z domain.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1998/08/20 16:22:01 $
%
%  $Revision: 2.1 $
%
%  $Log: genfwdmat.m,v $
%  Revision 2.1  1998/08/20 16:22:01  rjg
%  Moved reseting of SVD flags inside function.
%
%  Revision 2.0  1998/08/05 17:58:36  rjg
%  This function handles calculation of the forward matrice(s) and
%  incident fields.  Moved into a function to make cleanup automatic
%  and handle multiple wavelengths.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmiModel = genFwdMat(pmiModel, Debug)

if nargin < 2
    Debug = 0;
end

%%
%%  Source modulation frequency and source & detector positions
%%
[pSrc nSrc]= getOptodePos(pmiModel.Src);
[pDet nDet]= getOptodePos(pmiModel.Det);
nSDPair = nDet * nSrc;

%%
%%  Preallocate the memory for the forward matrices and incident field
%%
if strcmp('uniform', lower(pmiModel.CompVol.Type))
    nX = length(pmiModel.CompVol.X);
    nY = length(pmiModel.CompVol.Y);
    nZ = length(pmiModel.CompVol.Z);
    nCompElem = nX * nY *nZ;
else
    nCompElem = size(pmiModel.CompVol.Pos);
end
nLambda = length(pmiModel.Mu_a);
nFreq = length(pmiModel.ModFreq);
nMeas = nSDPair * (nFreq + sum(pmiModel.ModFreq > 0));

pmiModel.A = zeros(nMeas, nCompElem, nLambda);
pmiModel.PhiInc = zeros(nMeas, nLambda);

if ~isfield(pmiModel, 'MeasList')
    pmiModel.MeasList = FullMeasList(nDet, nSrc, nLambda, nLambda);
end

%%
%%  Loop over wavelength
%%
for idxLambda = 1:nLambda
    %%
    %%  Move the effective source position 1 mean free path into the medium
    %%
    EffpSrc = [pSrc(:,1) pSrc(:,2) pSrc(:,3)-(1/pmiModel.Mu_sp(idxLambda))];

    %%
    %%  Generate a forward matrix for each frequency
    %%
    idxRow = 1;
    for idxFreq = 1:nFreq

        switch lower(pmiModel.Boundary.Geometry)
         case { 'semi-infinite', 'semi', 'extrapolated'}
          if Debug
              fprintf(['Executing extrapolated zero boundary' ...
                       ' computation\n']);
          end
          [A PhiInc] = DPDWBorn1ZB(pmiModel, EffpSrc, pDet, idxLambda, ...
                                   idxFreq, Debug);
          
         case {'infinite', 'inf'}
          if Debug
              fprintf(['Executing infinite medium boundary' ...
                       ' computation\n']);
          end
          [A PhiInc] = DPDWBorn1NB(pmiModel, EffpSrc, pDet, idxLambda, ...
                                   idxFreq, Debug);
        
         otherwise
          error(['Unknown boundary condition: ' pmiModel.Boundary.Geometry]);
        end

        %%
        %%  Scale the amplitude of the forward matrix and incident field if 
        %%  necessary.
        %%
        if any(pmiModel.Src.Amplitude ~= 1) | any(pmiModel.Det.Amplitude ~= 1)
            disp('NEED TO VALIDATE MATRIX WEIGHTING!');
            SDWeight = pmiModel.Det.Amplitude' * pmiModel.Src.Amplitude;
            SDWeight = SDWeight(:);
            A = rowscale(A, SDWeight);
            PhiInc = SDWeight .* PhiInc;
        end

        %%
        %%  Copy the forward matrix into the correct block
        %%
        pmiModel.A(idxRow:idxRow+nSDPair-1,:,idxLambda) = real(A);
        pmiModel.PhiInc(idxRow:idxRow+nSDPair-1,idxLambda) = real(PhiInc);
        idxRow = idxRow + nSDPair;            
        if pmiModel.ModFreq(idxFreq) > 0
            pmiModel.A(idxRow:idxRow+nSDPair-1,:,idxLambda) = imag(A);
            pmiModel.PhiInc(idxRow:idxRow+nSDPair-1,idxLambda) = imag(PhiInc);
            idxRow = idxRow + nSDPair;
        end
    end
end

