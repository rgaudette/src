%mergePMIStr    Merge 2 PMI structures
%
%   pmi = mergePMIStr(pmi1, pmi2)
%
%   pmi         The resultant structure.
%
%   pmi1        The subordinate structure
%
%   pmi2        The superior structure.
%
%
%   mergePMIStr merges two PMI structures with any top level fields in pmi2
%   replacing all top level fields in pmi1 with those that exist in pmi2.
%
%   Calls: none.
%
%   Bugs: this function should really only replace data fields that exist in
%   pmi2.  This needs to be done recursively with isstruct and fieldnames.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author:$
%
%  $Date:$
%
%  $Revision:$
%
%  $Log:$
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = mergePMIStr(pmi1, pmi2)

pmi = pmi1;

TopFields = fieldnames(pmi2);

for iField = 1:length(TopFields)
    pmi = setfield(pmi, TopFields{iField}, getfield(pmi2, TopFields{iField}));
end
