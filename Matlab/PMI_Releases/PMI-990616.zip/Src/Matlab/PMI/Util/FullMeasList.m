%FullMeasList   Create a full measurement list

function MeasList = FullMeasList(nDet, nSrc, nFreq, nLambda)
%%
%%  Create the full MeasList matrix
%%
DOrder = repmat([1:nDet]', nSrc*nFreq*nLambda, 1);
tmp = repmat([1:nSrc], nDet, 1);
tmp = tmp(:);
SOrder = repmat(tmp, nFreq*nLambda, 1);
tmp = repmat([1:nFreq], nDet*nSrc, 1);
tmp = tmp(:);
FOrder = repmat(tmp, nLambda, 1);
tmp = repmat([1:nLambda], nDet*nSrc*nFreq, 1);
LOrder = tmp(:);

MeasList = [DOrder SOrder FOrder LOrder];
