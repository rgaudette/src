%getOptodePos   Get the optode position and number from the optode data structure.
%
%   [pOptode, nOptode] = getOptodePos(OptodePos);

%%
%%  Convert a uniform optode array into a matrix of positions if necessary
%%
function [pOptode, nOptode] = getOptodePos(OptodePos);
if strcmp(OptodePos.Type, 'uniform')
    [Xp Yp Zp] = meshgrid(OptodePos.X, OptodePos.Y,OptodePos.Z);
    nOptode = prod(size(Xp));
    pOptode = [Xp(:) Yp(:) Zp(:)];
else
    nOptode = size(OptodePos.Pos, 1);
    pOptode = pmiModel.OptodePos.Pos;
end
