%getFwdModelInfo Get the forward model info from the GUI.
%
%   pmi = getFwdModelInfo(pmi)
%
%   pmi         The Photon Migration Imaging data structure to fill in.  If
%               this is not present in the input argument list it will be
%               created.
%
%   getFwdModelInfo extracts the forward model info from the GUI and fills
%   in the PMI data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: $
%
%  $Date: $
%
%  $Revision: $
%
%  $Log: $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = getFwdModelInfo(pmi)

if nargin < 1
    pmi = [];
end

%%
%%  Get the handle structure from the current figure's user data.
%%
UIHandles = get(gcf, 'UserData');

if ~isfield(pmi, 'Version')
    pmi.Version = 3;
end

if ~isfield(pmi, 'Debug')
    pmi.Debug = 0;
end

%%
%%  Medium paramters
%%
pmi.Fwd.Lambda = eval(get(UIHandles.Fwd_Lambda, 'string'));
nLambda = length(pmi.Fwd.Lambda);

pmi.Fwd.idxRefr = eval(get(UIHandles.Fwd_idxRefr, 'string'));
if length(pmi.Fwd.idxRefr) ~= nLambda
    warning(['Number of index of refraction parameters must match the number of' ...
             ' wavelengths']);
end
pmi.Fwd.Mu_s = eval(get(UIHandles.Fwd_Mu_s, 'string'));
if length(pmi.Fwd.Mu_s) ~= nLambda
    warning(['Number of mu_s must match the number of' ...
             ' wavelengths']);
end

pmi.Fwd.g = eval(get(UIHandles.Fwd_g, 'string'));
if length(pmi.Fwd.g) ~= nLambda
    warning(['Number of mean cosine angle parameters must match the number of' ...
             ' wavelengths']);
end

pmi.Fwd.Mu_a = eval(get(UIHandles.Fwd_Mu_a, 'string'));
if length(pmi.Fwd.Mu_a) ~= nLambda
    warning(['Number of mu_a parameters must match the number of' ...
             ' wavelengths']);
end


pmi.Fwd.Mu_sp = pmi.Fwd.Mu_s .* (1 - pmi.Fwd.g);
pmi.Fwd.v = 3.0E10 ./ pmi.Fwd.idxRefr;

%%
%%  Source & Detector Data
%%
pmi.Fwd.ModFreq = eval(get(UIHandles.Fwd_ModFreq, 'string'));

pmi.Fwd.Src.Type = 'uniform';
pmi.Fwd.Src.X = eval(get(UIHandles.Fwd_SrcXPos, 'string'));
pmi.Fwd.Src.Y = eval(get(UIHandles.Fwd_SrcYPos, 'string'));
pmi.Fwd.Src.Z = eval(get(UIHandles.Fwd_SrcZPos, 'string'));

[pos nSrc] = getOptodePos(pmi.Fwd.Src);
Normal = eval(get(UIHandles.FwdSrc_Normal, 'string'));
if size(Normal, 1) == 1
    pmi.Fwd.Src.Normal = repmat(Normal, nSrc, 1);
else
    pmi.Fwd.Src.Normal = Normal;
end

Amplitude = eval(get(UIHandles.FwdSrc_Amp, 'string'));
if length(Amplitude) == 1
    pmi.Fwd.Src.Amplitude = repmat(Amplitude, 1, nSrc);
else
    pmi.Fwd.Src.Amplitude = Amplitude;
end

NA =  eval(get(UIHandles.FwdSrc_NA, 'string'));
if length(NA) == 1
    pmi.Fwd.Src.NA = repmat(NA, 1, nSrc);
else
    pmi.Fwd.Src.NA = NA;
end


pmi.Fwd.Det.Type = 'uniform';
pmi.Fwd.Det.X = eval(get(UIHandles.Fwd_DetXPos, 'string'));
pmi.Fwd.Det.Y = eval(get(UIHandles.Fwd_DetYPos, 'string'));
pmi.Fwd.Det.Z = eval(get(UIHandles.Fwd_DetZPos, 'string'));;

[pos nDet] = getOptodePos(pmi.Fwd.Det);

Normal = eval(get(UIHandles.FwdDet_Normal, 'string'));
if size(Normal, 1) == 1
    pmi.Fwd.Det.Normal = repmat(Normal, nDet, 1);
else
    pmi.Fwd.Det.Normal = Normal;
end

Amplitude = eval(get(UIHandles.FwdDet_Amp, 'string'));
if length(Amplitude) == 1
    pmi.Fwd.Det.Amplitude = repmat(Amplitude, 1, nDet);
else
    pmi.Fwd.Det.Amplitude = Amplitude;
end

NA =  eval(get(UIHandles.FwdDet_NA, 'string'));
if length(NA) == 1
    pmi.Fwd.Det.NA = repmat(NA, 1, nDet);
else
    pmi.Fwd.Det.NA = NA;
end

if get(UIHandles.Fwd_InfMedium, 'value')
    pmi.Fwd.Boundary.Geometry = 'Infinite';
end
if get(UIHandles.Fwd_SemiInfinite, 'value')
    pmi.Fwd.Boundary.Geometry = 'Semi-infinite';
end

%%
%%  Forward model method
%%
if get(UIHandles.Fwd_MatlabVar,'value')
    pmi.Fwd.Method.Type = 'Matlab Variable'
    pmi.Fwd.Method.MatlabVarName = eval(get(UIHandles.Fwd_MatlabVarName, ...
        'string'));
end
if get(UIHandles.Fwd_Born,'value')
    pmi.Fwd.Method.Type = 'Born';
    pmi.Fwd.Method.Order = eval(get(UIHandles.Fwd_Order, 'string'));
end
if get(UIHandles.Fwd_Rytov,'value')
    pmi.Fwd.Method.Type = 'Rytov';
end
if get(UIHandles.Fwd_Spherical,'value')
    pmi.Fwd.Method.Type = 'Spherical';
    pmi.Fwd.Method.Order = eval(get(UIHandles.Fwd_Order, 'string'));
end

if get(UIHandles.Fwd_FDFD,'value')
    pmi.Fwd.Method.Type = 'FDFD';
end
if get(UIHandles.Fwd_FiniteElem,'value')
    pmi.Fwd.Method.Type = 'FEM';
end

if ~(strcmp(pmi.Fwd.Method.Type, 'Spherical') | ...
        strcmp(pmi.Fwd.Method.Type, 'MatlabVariable'))
    %%
    %%  Computation Volume Parameters
    %%
    XMin = eval(get(UIHandles.Fwd_XMin, 'string'));
    XMax = eval(get(UIHandles.Fwd_XMax, 'string'));
    XStep = eval(get(UIHandles.Fwd_XStep, 'string'));
    YMin = eval(get(UIHandles.Fwd_YMin, 'string'));
    YMax = eval(get(UIHandles.Fwd_YMax, 'string'));
    YStep = eval(get(UIHandles.Fwd_YStep, 'string'));
    ZMin = eval(get(UIHandles.Fwd_ZMin, 'string'));
    ZMax = eval(get(UIHandles.Fwd_ZMax, 'string'));
    ZStep = eval(get(UIHandles.Fwd_ZStep, 'string'));
    pmi.Fwd.CompVol.Type = 'uniform';
    pmi.Fwd.CompVol.X = [XMin:XStep:XMax];
    pmi.Fwd.CompVol.Y = [YMin:YStep:YMax];
    pmi.Fwd.CompVol.Z = [ZMin:ZStep:ZMax];
    pmi.Fwd.CompVol.XStep = XStep;
    pmi.Fwd.CompVol.YStep = YStep;
    pmi.Fwd.CompVol.ZStep = ZStep;
end
