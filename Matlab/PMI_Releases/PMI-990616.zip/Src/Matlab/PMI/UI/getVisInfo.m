%getVisInfo     Get the visualization info from the GUI.
%
%   pmi = getvisinfo(pmi)
%
%   pmi         The Photon Migration Imaging data structure to fill in.  If
%               this is not present in the input argument list it will be
%               created.
%
%   getVisInfo extracts the visualization info from the GUI and fills
%   in the PMI data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1998/08/07 21:31:07 $
%
%  $Revision: 2.1 $
%
%  $Log: getVisInfo.m,v $
%  Revision 2.1  1998/08/07 21:31:07  rjg
%  Added radio button for selecting which dimension to slice in.
%
%  Revision 2.0  1998/08/05 16:32:50  rjg
%  *** empty log message ***
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = getVisInfo(pmi)

if nargin < 1
    pmi = [];
end

%%
%%  Get the handle structure from the current figure's user data.
%%
UIHandles = get(gcf, 'UserData');


%%
%%  Visualiztion parameters
%%
if get(UIHandles.XPlane, 'value')
    pmi.Visualize.VisPlane = 'X';
end
if get(UIHandles.YPlane, 'value')
    pmi.Visualize.VisPlane = 'Y';
end
if get(UIHandles.ZPlane, 'value')
    pmi.Visualize.VisPlane = 'Z';
end

if get(UIHandles.Image, 'value')
    pmi.Visualize.Type = 'image';
else
    pmi.Visualize.Type = 'contour';
    pmi.Visualize.nCLines = eval(get(UIHandles.nCLines, 'string'));
end

pmi.Visualize.PlaneIndices = eval(get(UIHandles.PlaneIndices, 'string'));
pmi.Visualize.LayoutVector = eval(get(UIHandles.LayoutVector, 'string'));

if get(UIHandles.CMapBgyor, 'value')
    pmi.Visualize.CMap = 'bgyor';
else
    pmi.Visualize.CMap = 'grey';
end

if get(UIHandles.CRangeAuto, 'value')
    pmi.Visualize.CRange = 'auto';
else
    pmi.Visualize.CRange = 'fixed';
    pmi.Visualize.CRangeVal = eval(get(UIHandles.CRangeVal, 'string'));
end
