%tabInvProb
function tabInvProb()

UIHandles = get(gcf, 'UserData');

set(UIHandles.vTAB1, 'visible', 'off');
set(UIHandles.vTAB2, 'visible', 'on');
set(UIHandles.InvProbTab, 'FontWeight', 'bold');
set(UIHandles.FwdProbTab, 'FontWeight', 'light');
