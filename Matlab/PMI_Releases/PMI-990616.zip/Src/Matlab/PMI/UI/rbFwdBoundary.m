%rbFwdBoundary     Boundary selector radio button control function.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: $
%
%  $Date: $
%
%  $Revision: $
%
%  $Log: $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rbFwdBoundary(str)

UIHandles = get(gcf, 'UserData');

switch lower(str)
case {'infinite', 'inf'}
    set(UIHandles.Fwd_SemiInfinite, 'value', 0);
    set(UIHandles.Fwd_InfMedium, 'value', 1);
case {'semi-infinite', 'semi', 'extrapolated'}
    set(UIHandles.Fwd_InfMedium, 'value', 0);
    set(UIHandles.Fwd_SemiInfinite, 'value', 1);
end
