%getRecInfo     Get the reconstruction parameters from the GUI.
%
%   pmi = getRecInfo(pmi)
%
%   pmi         The Photon Migration Imaging data structure to fill in.  If
%               this is not present in the input argument list it will be
%               created.
%
%   getRecInfo extracts the reconstruction info from the GUI and fills
%   in the PMI imaging data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1998/08/05 16:35:11 $
%
%  $Revision: 2.0 $
%
%  $Log: getRecInfo.m,v $
%  Revision 2.0  1998/08/05 16:35:11  rjg
%  Broke up getall.m
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = getRecInfo(pmi)

if nargin < 1
    pmi = [];
end

%%
%%  Get the handle structure from the current figure's user data.
%%
UIHandles = get(gcf, 'UserData');

%%
%%  Reconstruction algorithm
%%
if get(UIHandles.BackProj, 'value')
    pmi.Recon.ReconAlg = 'Back Projection';
end

if get(UIHandles.ART, 'value')
    pmi.Recon.ReconAlg = 'ART';
    pmi.Recon.ARTnIter = eval(get(UIHandles.ARTnIter, 'string'));
end

if get(UIHandles.SIRT, 'value')
    pmi.Recon.ReconAlg = 'SIRT';
    pmi.Recon.SIRTnIter = eval(get(UIHandles.SIRTnIter, 'string'));
end

if get(UIHandles.MinNorm, 'value')
    pmi.Recon.ReconAlg = 'Min. Norm';
end

if get(UIHandles.TSVD, 'value')
    pmi.Recon.ReconAlg = 'TSVD';
    pmi.Recon.TSVDnSV = eval(get(UIHandles.TSVDnSV, 'string'));
end

if get(UIHandles.MTSVD, 'value')
    pmi.Recon.ReconAlg = 'MTSVD';
    pmi.Recon.MTSVDnSV = eval(get(UIHandles.MTSVDnSV, 'string'));
    pmi.Recon.MTSVDLambda = eval(get(UIHandles.MTSVDLambda, 'string'));
end

if get(UIHandles.TCG, 'value')
    pmi.Recon.ReconAlg = 'TCG';
    pmi.Recon.TCGnIter = eval(get(UIHandles.TCGnIter, 'string'));
end
