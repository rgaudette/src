%getMetaData    Get the meta data info from the GUI.
%
%   pmi = getMetaData(pmi)
%
%   pmi         The Photon Migration Imaging data structure to fill in.  If
%               this is not present in the input argument list it will be
%               created.
%
%   getFwdModelInfo extracts the forward model info from the GUI and fills
%   in the PMI data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.
function pmi = getMetaData(pmi)
UIHandles = get(gcf, 'userdata');
pmi.Version = UIHandles.Version;
pmi.Debug = UIHandles.Debug;
