%doMeasData     Calculate the measured data from the slab image parms.
%
%   This script extracts the current system parameters from the GUI Slab
%   image interface and calculates the measured data (detector responses).
%
%   Calls: getmdinfo, genmeasdata
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: rjg $
%
%  $Date: 1998/12/23 16:41:23 $
%
%  $Revision: 2.7 $
%
%  $Log: doMeasData.m,v $
%  Revision 2.7  1998/12/23 16:41:23  rjg
%  Fixed help comments.
%
%  Revision 2.6  1998/08/20 18:57:23  rjg
%  Moved all processing operations into a single function so that batch
%  processing is possible.
%
%  Revision 2.5  1998/08/12 19:34:38  rjg
%  Fixed handling of detector side noise for multi-wavelength cases.
%
%  Revision 2.4  1998/08/07 19:29:58  rjg
%  No code changes, fixed log field.
%
%  Revision 1.2  1998/04/29 15:13:04  rjg
%  Added busy light.
%
%  Revision 1.1  1998/04/28 20:17:51  rjg
%  Initial revision
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

UIHandles = get(gcf, 'UserData');
set(UIHandles.hLight, 'Color', [1 0 0]);
drawnow;

if exist('dsPMI', 'var')
    dsPMI = getFwdModelInfo(dsPMI);
else
    dsPMI = getMetaData;
    dsPMI = getFwdModelInfo(dsPMI);
end
dsPMI = getObjectInfo(dsPMI);

%%
%%  Generate the measured data.
%%
dsPMI = genMeasData(dsPMI);

if dsPMI.Debug
    fprintf('Max Incident-to-Purturbation-Ratio: %f dB\n', ...
        20*log10(max(dsPMI.Fwd.IPR)));
    fprintf('Min Incident-to-Purturbation-Ratio: %f dB\n', ...
        20*log10(min(dsPMI.Fwd.IPR)));
end

set(UIHandles.hLight, 'Color', [0 1 0]);
drawnow;
clear UIHandles;