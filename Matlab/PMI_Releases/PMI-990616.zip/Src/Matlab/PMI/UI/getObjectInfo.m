%getObjectInfo  Get the object anomaly info from the GUI.
%
%   pmi = getObjectInfo(pmi)
%
%   pmi         The Photon Migration Imaging data structure to filled in.
%               If this is not present in the input argument list it will
%               be created.
%
%   getObjectInfo extracts the anomally data from the GUI and fills
%   in the PMI imaging data structure with the appropriate values.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: $
%
%  $Date: $
%
%  $Revision: $
%
%  $Log: $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function pmi = getObjectInfo(pmi)

if nargin < 1
    pmi = [];
end

%%
%%  Get the handle structure from the current figure's user data.
%%
UIHandles = get(gcf, 'UserData');

%%
%%  Sphere object(s) parameters
%%
nSpheres = 0;
strTmp = get(UIHandles.SphereRad, 'string');
if ~strcmp(strTmp, '')
    SphereRad = eval(strTmp);
end
strTmp = get(UIHandles.SphereDelta, 'string');
if ~strcmp(strTmp, '')
    SphereDelta = eval(strTmp);
end
strTmp = get(UIHandles.SphereCtr, 'string');
if ~strcmp(strTmp, '')
    SphereCtr = eval(strTmp);
    nSpheres = size(SphereCtr, 1);
    for i = 1:nSpheres
        pmi.Object{i}.Type = 'sphere';
        pmi.Object{i}.Pos = SphereCtr(i,:);
        pmi.Object{i}.Radius = SphereRad(i);
        pmi.Object{i}.Mu_a = SphereDelta(i,:);
    end
end

%%
%%  Block object.(s) parameters
%%
strTmp = get(UIHandles.BlockDims, 'string');
if ~strcmp(strTmp, '')
    BlockDims = eval(strTmp);
end
strTmp = get(UIHandles.BlockDelta, 'string');
if ~strcmp(strTmp, '')
    BlockDelta = eval(strTmp);
end
strTmp = get(UIHandles.BlockCtr, 'string');
if ~strcmp(strTmp, '')
    BlockCtr = eval(strTmp);

    nBlocks = size(BlockCtr, 1);
    for i = 1:nBlocks
        pmi.Object{i+nSpheres}.Type = 'block';
        pmi.Object{i+nSpheres}.Pos = BlockCtr(i,:);
        pmi.Object{i+nSpheres}.Rad = BlockDims(i,:);
        pmi.Object{i+nSpheres}.Mu_a = BlockDelta(i,:);
    end
end