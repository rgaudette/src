%tabFwdProb
function tabFwdProb()

UIHandles = get(gcf, 'UserData');

set(UIHandles.vTAB2, 'visible', 'off');
set(UIHandles.vTAB1, 'visible', 'on');
set(UIHandles.FwdProbTab, 'FontWeight', 'bold');
set(UIHandles.InvProbTab, 'FontWeight', 'light');
