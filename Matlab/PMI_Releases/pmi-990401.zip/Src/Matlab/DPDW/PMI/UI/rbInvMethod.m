%rbInvMethod    Inverse method radio button selection.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author: $
%
%  $Date: $
%
%  $Revision: $
%
%  $Log: $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rbInvMethod(value)
UIHandles = get(gcf, 'UserData');

switch value

case 'Born'
    set(UIHandles.Inv_Rytov, 'value', 0);
    set(UIHandles.Inv_Born, 'value', 1);

case 'Rytov'
    set(UIHandles.Inv_Born, 'value', 0);
    set(UIHandles.Inv_Rytov, 'value', 1);
end
