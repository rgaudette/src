%cleanFwdSys    Delete the forward system matrix from the PMI data structure.
%
%   ds = cleanFwdSys(ds);
%
%   ds          The PMI data structure to operate upon.
%
%
%   cleanFwdSys sets the forward system to matrix to empty to conserve memory.
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author:$
%
%  $Date:$
%
%  $Revision:$
%
%  $Log:$
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ds = cleanFwdSys(ds);
ds.Fwd.A =[];
