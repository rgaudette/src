%FATTSVDALL     Truncated SVD solution to a fat matrix problem for all r.
%
%   [xtsvd U S V]= fattsvdall(A, b, U, S, V)
%
%
%   Calls: none.
%
%   Bugs: none known.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  $Author:$
%
%  $Date:$
%
%  $Revision:$
%
%  $Log:$
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [xtsvd, U, S, V] = fattsvdall(A, b, U, S, V)

[m n] = size(A);

%%
%%  Compute the economy SVD of the tall problem if necessary
%%
if nargin < 5
    [V S U] = svd(A', 0);
end
xtsvd = zeros(n, m);
bproj = A' * b;

for r = 1:m
    xtsvd(:,r) = U(:,1:r) * (diag(S(1:r,1:r)).^-2 .* ((U(:,1:r))' * bproj));
end
